```text
.....                                                 .,,.,,,...f            Press } to open sidebar options
.......               lqqqqqqqqqqqqk lqqqqqqk lqqqqqk                                               ████   L ARM: █████
 ........            <xACHIEVEMENTSx>xSCORESx xKILLSx                                               ████   R LEG: █████
   ........         lqj            mqvqqqqqqvqvqqqqqvqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk|      Focus: 96
     .......        ^[Combat] Decamate                                                             x00     Move : 105(W)
        ......      x  Kill at least 10 monsters (0/10)                                            xana : 1100
          ......    x  Triggered by monster killed                                                 x       Power: 250kJ
            ......  x                                                                              x2      Safe : On
              ..... x[Combat] One Down, Billions to Go…                                            x               .....
                ....x  Kill at least 1 zombie (0/1)                                                x               .....
                  ..x  Triggered by zombie killed                                                  x               ..+..
                    x                                                                              x               .┌┘..
.                   x[Combat] Pacifist                                                             x               ┌┘...
.......             x  At least 1 week from start of game (6 days and 23 hours remaining)          x
.............       x  Don't kill even a single monster                                            x
................... x  Triggered by monster killed                                                 x
.........*..........x  Triggered by wake up                                                        xolume:0.85/17.50
....................x                                                                              xhirst:Hydrated
....................x[Combat] Rude Awakening                                                       xunger:Sated
.....               x  Within 1 minute of start of game (42 seconds remaining)                     x
                    x  Kill at least 1 monster (0/1)                                               x
                    x  Triggered by monster killed                                                 x
                    x                                                                              xan be closed
                    x[Skill] Ace Driver                                                            x
                    x  No turn is too sharp.                                                       xery to reload your
                    x  Attain skill level of 5 in Driving (0/5)                                    x
                    x  Triggered by driving skill level up.                                        xk up nearby.
                    x                                                                              x
                    x[Skill] Batter                                                                xk up nearby.
                    x  Every strike brings me closer to a home run.                                x
                   .x  Attain skill level of 5 in Bashing Weapons (0/5)                            x
                  ..x  Triggered by bashing weapons skill level up.                                x     NE:
                 ...x                                                                              x   East:
                ....x[Skill] Brawler                                                               x     SE:
               .....x  Bottle in left hand, chair leg in right hand.                               x
              ......x  Attain skill level of 5 in Melee (0/5)                                      x
             .......v  Triggered by melee skill level up.                                          x
            ........mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj
           .....................

```
