```text
                                                                             Press } to open sidebar options
                                                                             HEAD : █████   TORSO: █████   L ARM: █████
                                                                             R ARM: █████   L LEG: █████   R LEG: █████
                                                                             Sound: 11      Mood : :|      Focus: 96
                                                                             Stam : ████▁   Speed: 100     Move : 80(W)
                                                                             Mana : 1006       Max Mana : 1100
                                                                             Str  : 12      Dex  : 7       Power: 250kJ
                                ..                                           Int  : 9       Per  : 12      Safe : On
                               qq"q                                          Place: evac shelter                   .....
                                #...                                         X,Y,Z: -43, -61, 0                    .....
                                6...                                         Sky  : Fair                           ..+..
                               qq....                                        Light: bright                         .┌┘..
                              x#=.#..                                        Date : Spring, day 16                 ┌┘...
                             .x#..#..                                        Time : 8:00:07 AM
                             ."#..#...                                       Wield: fists
                              x#..#...                                       Style: No style
                              x...#...                                       Wgt  : 4.6/61.0       Volume:0.85/17.50
                              x#..#...qqq        x                           Pain :                Thirst:Hydrated
                             .x#..#..@##{{...#..#x.                          Rest :                Hunger:Sated
                             .0...#...@......#..#0.                          Heat : Comfortable
                             .x...#...##.##.....#x.                          Sound: 11
                              mqq.............qq x                           in one of the many government evac
                                {............                                shelters.
                                {........6###                                You hear thump! x 3
                                {......&lqqqq                                You don't seem to be damaging the wooden
                                q0q+&q"qj                                    floor.
                                .. .....                                     You hear thump! x 2
                                                                             You don't seem to be damaging the wooden
                                                                             floor.
                                                                             You hear thump! x 4

                                                                             NW:           North:        NE:
                                                                             West:                     East:
                                                                             SW:           South:        SE:






```
