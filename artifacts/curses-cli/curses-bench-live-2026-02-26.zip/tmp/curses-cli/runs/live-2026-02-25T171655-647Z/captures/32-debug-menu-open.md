```text
.....                                                 .,,.,,,...f            Press } to open sidebar options
.......                                              ......,....             HEAD : █████   TORSO: █████   L ARM: █████
 ........                                           ..........            .. R ARM: █████   L LEG: █████   R LEG: █████
   ........                                        ,........            .... Sound: 6       Mood : :|      Focus: 96
     .......                                      ....,.,.            ...... Stam : ████▁   Speed: 100     Move : 0(W)
        ......            ..                     .......,           ........ Mana : 1006       Max Mana : 1100
          ......         qq"q                   .......           .......... Str  : 12      Dex  : 7       Power: 250kJ
            ......        #...  .qqqqqq        .......         ............. Int  : 9       Per  : 12      Safe : On
              .....       6...   .......      ......         ............... Place: evac shelter                   .....
                .....    qq....   ##.....  x .....         ................. X,Y,Z: -43, -61, 0                    .....
                  ..... x#..#..   .....#.. x....         ................... Sky  : Fair                           ..+..
                    ....x#..#..    #...#..#x...        ..................... Light: bright                         .┌┘..
.                     .."#..#lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk, day 16                 ┌┘...
.......                 x#..#x Debug Functions - Manipulate the fabric of reality!       x8 AM
.............           x...#x You can use them to fix a bug or test something.          x
...................     x#..#x Be careful, as some of them may potentially break things. xle
.........*..............x#..#tqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqu.0       Volume:0.85/17.50
........................0...#x i Info…                                                   x         Thirst:Hydrated
........................x...#x Q Quit to main menu                                       x         Hunger:Sated
.....                   mqq..x s Spawning…                                               xtable
                          {..x p Player…                                                 x
                          {..x v Vehicle…                                                x
                          {..x t Teleport…                                               xing that can be closed
                          q0qx m Map…                                                    x
                         ....x l Lua console                                             xe any battery to reload your
                        ..:..mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj!
                       ...:....:.                                            There is nothing to pick up nearby.
                      ....:....:.                                            Never mind.
                     .....:....:.                                            There is nothing to pick up nearby.
                    ......:....:.                                            Never mind.
                   ..............
                  ..............:                                            NW:           North:        NE:
                 ..............::                                            West:                     East:
                ..............::.                                            SW:           South:        SE:
               ..................
              ..............::..
             ..............::...
            ..............::....
           .....................

```
