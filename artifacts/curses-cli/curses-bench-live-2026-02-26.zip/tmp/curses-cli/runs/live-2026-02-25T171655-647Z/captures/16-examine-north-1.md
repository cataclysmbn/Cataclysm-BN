```text
.                                                      ,,,,.,.......         Press } to open sidebar options
...                                                   ..,,,.,,.,..           HEAD : █████   TORSO: █████   L ARM: █████
....                                                 .,,.,,,...f             R ARM: █████   L LEG: █████   R LEG: █████
......                                              ......,....              Sound: 6       Mood : :|      Focus: 96
........                                           ..........                Stam : ████▁   Speed: 100     Move : 0(W)
  ........                                        ,........                  Mana : 1006       Max Mana : 1100
    .......                                      ....,.,.                    Str  : 12      Dex  : 7       Power: 250kJ
       ......            ..                     .......,                     Int  : 9       Per  : 12      Safe : On
         ......         qq"q                   .......                       Place: evac shelter                   .....
           ......        #...  .qqqqqq        .......                        X,Y,Z: -43, -61, 0                    .....
             .....       6...   .......      ......                          Sky  : Fair                           ..+..
               .....    qq....   ##.....  x .....                            Light: bright                         .┌┘..
                 ..... x#..#..   .....#.. x....                              Date : Spring, day 16                 ┌┘...
                   ....x#..#..    #...#..#x...                               Time : 8:00:14 AM
                     .."#..#... qqq...#..#".                                 Wield: fists
                       x#..#... >>....#...x                           ...... Style: No style
                       x...#...  >....#..#      lqqqqqqqqqqqqqqqqqqqqqk..... Wgt  : 4.6/61.0       Volume:0.85/17.50
....                   x#..#...qqqq...#..#x     x Select an action    x..... Pain :                Thirst:Hydrated
........*..............x#..#..@##{{...#..#x.....tqqqqqqqqqqqqqqqqqqqqqu..... Rest :                Hunger:Sated
.......................0...#..........@..#0.....x g Get items         x..... Heat : Comfortable
.......................x...#...##.##.....#x.....x t Set bench upright x..... Sound: 6
....                   mqq.............lqqj     mqqqqqqqqqqqqqqqqqqqqqj..... You hear thump! x 4
                         {.............+                     ............... That is a wooden floor.
                         {........6####x                              ...... You feel a twinge of panic as darkness
                         {......&lqqqqq                                      engulfs you.
                         q0q+&q"qj                                           That is a wooden floor.
                        .........                                            You feel relief as you step back into the
                       ..:....:.                                             light.
                      ...:....:.                                             Moving onto this bench is slow!
                     ....:....:.                                             That is a wooden floor.
                    .....:....:.
                   ......:....:.                                             NW:           North:        NE:
                  ..............                                             West:                     East:
                 ..............:                                             SW:           South:        SE:
                ..............::
               ..............::.
              ..................
             ..............::..
            ..............::...

```
