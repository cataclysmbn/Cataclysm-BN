```text
 ......                                                                      Press } to open sidebar options
   ......                                                                    HEAD : █████   TORSO: █████   L ARM: █████
     .....                                                                   R ARM: █████   L LEG: █████   R LEG: █████
       .....                                                                 Sound: 6       Mood : :|      Focus: 96
         .....                                                               Stam : ████▁   Speed: 100     Move : 0(W)
           .....                                                             Mana : 1006       Max Mana : 1100
             ....                                                            Str  : 12      Dex  : 7       Power: 250kJ
              .....            ..                                            Int  : 9       Per  : 12      Safe : On
                .....         qq"q                                           Place: evac shelter                   .....
                  .....        #...                                          X,Y,Z: -43, -61, 0                    .....
                    ....       6...                                          Sky  : Fair                           ..+..
                      ....    qq....                                         Light: bright                         .┌┘..
                        .... x#=.#..                                         Date : Spring, day 16                 ┌┘...
                          ...x#..#..                                         Time : 8:00:08 AM
                            ."#..#...                                        Wield: fists
                             x#..#...                                        Style: No style
                             x...#...                                        Wgt  : 4.6/61.0       Volume:0.85/17.50
..........                   x#..#...qqq      . x                     ...... Pain :                Thirst:Hydrated
..............*..............x#..#..@##{{...#..#x........................... Rest :                Hunger:Sated
.............................0...#....@.....#..#0........................... Heat : Comfortable
.............................x...#...##.##.....#x........................... Sound: 6
..........                   mqq.............qq x                     ...... shelters.
                               {.............                                You hear thump! x 3
                               {........6###                                 You don't seem to be damaging the wooden
                               {......&lqqqq                                 floor.
                               q0q+&q"qj                                     You hear thump! x 2
                              ... .....                                      You don't seem to be damaging the wooden
                             ..: ...:.                                       floor.
                            ...  .. :.                                       You hear thump! x 4
                           ...  ... :.                                       That is a wooden floor.
                          ...   .. .:.
                         ...   :.. .:.                                       NW:           North:        NE:
                        ...    ..  ...                                       West:                     East:
                       ...    ...  ..:                                       SW:           South:        SE:
                      ...     ..  ..::
                     ...     ...  .::.
                    ...      ...  ....
                   ...      ...   :..
                  ...      ....   ...

```
