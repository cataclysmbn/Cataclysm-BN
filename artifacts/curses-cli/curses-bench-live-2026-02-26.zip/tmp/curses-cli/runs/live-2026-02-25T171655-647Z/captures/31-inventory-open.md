```text
.....                                                 .,,.,,,...f            Press } to open sidebar options
.......                                              ......,....             HEAD : █████   TORSO: █████   L ARM: █████
 ........                                           ..........            .. R ARM: █████   L LEG: █████   R LEG: █████
   ........                                        ,........            .... Sound: 6       Mood : :|      Focus: 96
     .......                                      ....,.,.            ...... Stam : ████▁   Speed: 100     Move : 0(W)
        ......            ..                     .......,           ........ Mana : 1006       Max Mana : 1100
          ......         qq"q                   .......           .......... Str  : 12      Dex  : 7       Power: 250kJ
            ......        #..lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk  Per  : 12      Safe : On
              .....       6..x Inventory                         Weight (kg):  4.6/ 61.0 xhelter                   .....
                .....    qq..x Item hotkeys assigned: 0/72        Volume (L): 0.85/17.50 x61, 0                    .....
                  ..... x#..#x                                                           x                         ..+..
                    ....x#..#tqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqu                         .┌┘..
.                     .."#..#x OTHER TOOLS                      ITEMS WORN               x, day 16                 ┌┘...
.......                 x#..#x   telescoping umbrella             || pair of socks       x8 AM
.............           x...#x ELECTRONICS                        || bra                 x
...................     x#..#x   reading light (150/150)          || panties             xle
.........*..............x#..#x BOOKS                              || suit                x.0       Volume:0.85/17.50
........................0...#x   file                             || pair of dress shoes x         Thirst:Hydrated
........................x...#x                                    || knit scarf          x         Hunger:Sated
.....                   mqq..x                                    || briefcase (left)    xtable
                          {..x                                                           x
                          {..x                                                           x
                          {..x                                                           xing that can be closed
                          q0qx                                                           x
                         ....x                                                           xe any battery to reload your
                        ..:..x                                                           x!
                       ...:..x                                                           xing to pick up nearby.
                      ....:..x                                                           x
                     .....:..x                                                           xing to pick up nearby.
                    ......:..x                                                           x
                   ..........x                                                           x
                  ...........mq< [/] Filter >qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj North:        NE:
                 ..............::                                            West:                     East:
                ..............::.                                            SW:           South:        SE:
               ..................
              ..............::..
             ..............::...
            ..............::....
           .....................

```
