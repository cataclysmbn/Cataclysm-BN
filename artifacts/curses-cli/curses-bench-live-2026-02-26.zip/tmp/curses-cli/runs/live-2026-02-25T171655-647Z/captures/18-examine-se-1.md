```text
.                                                      ,,,,.,.......         Press } to open sidebar options
...                                                   ..,,,.,,.,..           HEAD : █████   TORSO: █████   L ARM: █████
....                                                 .,,.,,,...f             R ARM: █████   L LEG: █████   R LEG: █████
......                                              ......,....              Sound: 6       Mood : :|      Focus: 96
........                                           ..........                Stam : ████▁   Speed: 100     Move : 0(W)
  ........                                        ,........                  Mana : 1006       Max Mana : 1100
    .......                                      ....,.,.                    Str  : 12      Dex  : 7       Power: 250kJ
       ......            ..                     .......,                     Int  : 9       Per  : 12      Safe : On
         ......         qq"q                   .......                       Place: evac shelter                   .....
           ......        #...  .qqqqqq        .......                        X,Y,Z: -43, -61, 0                    .....
             .....       6...   .......      ......                          Sky  : Fair                           ..+..
               .....    qq....   ##.....  x .....                            Light: bright                         .┌┘..
                 ..... x#..#..   .....#.. x....                              Date : Spring, day 16                 ┌┘...
                   ....x#..#..    #...#..#x...                               Time : 8:00:14 AM
                     .."#..#... qqq...#..#".                                 Wield: fists
                       x#..#... >>....#...x                           ...... Style: No style
                       x...#...  >....#..#                   ............... Wgt  : 4.6/61.0       Volume:0.85/17.50
....                   x#..#...qqqq...#..#x         ........................ Pain :                Thirst:Hydrated
........*..............x#..#..@##{{...#..#x................................. Rest :                Hunger:Sated
.......................0...#..........@..#0................................. Heat : Comfortable
.......................x...#...##.##.....#x................................. Sound: 6
....                   mqq.............lqqj         ........................ You feel a twinge of panic as darkness
                         {.............+                     ............... engulfs you.
                         {........6####x                              ...... That is a wooden floor.
                         {......&lqqqqq                                      You feel relief as you step back into the
                         q0q+&q"qj                                           light.
                        .........                                            Moving onto this bench is slow!
                       ..:....:.                                             That is a wooden floor.
                      ...:....:.                                             That is a flipped bench.
                     ....:....:.                                             That is a wooden floor. x 2
                    .....:....:.
                   ......:....:.                                             NW:           North:        NE:
                  ..............                                             West:                     East:
                 ..............:                                             SW:           South:        SE:
                ..............::
               ..............::.
              ..................
             ..............::..
            ..............::...

```
