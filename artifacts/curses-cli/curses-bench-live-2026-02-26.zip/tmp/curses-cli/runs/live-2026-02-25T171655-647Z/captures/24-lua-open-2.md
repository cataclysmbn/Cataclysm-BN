```text
lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x Lua online.                                                                                                          x
x bn: preloaded.                                                                                                       x
x nuclear tear mod loaded                                                                                              x
x ebook_lua: preload online.                                                                                           x
x──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────x
xPress Enter to enter/edit command, Esc to quit                                                                        x
xPress Up/Down arrows to select from history                                                                           x
xPress PgUp/PgDn/Home/End to scroll output window, TAB to toggle expanded input view                                   x
x──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────x
x  1                                                                                                                   x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj

```
