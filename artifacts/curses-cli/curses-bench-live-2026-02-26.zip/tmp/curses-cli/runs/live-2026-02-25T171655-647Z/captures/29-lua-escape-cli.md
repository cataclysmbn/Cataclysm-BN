```text
lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x                                                                                                                      x
x Lua online.                                                                                                          x
x bn: preloaded.                                                                                                       x
x nuclear tear mod loaded                                                                                              x
x ebook_lua: preload online.                                                                                           x
x──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────x
xPress Ctrl+S to run script, press Esc to cancel                                                                       x
xPress arrow keys to navigate text input                                                                               x
xPress Enter to add new line                                                                                           x
x──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────x
x  1 gapi.get_avatar():create_item(ItypeId.new("makeshift_crowbar"), 1)                                                x
x  2 gapi.place_monster_around(MtypeId.new("mon_zombie"), gapi.get_avatar():get_pos_ms(), 2)                           x
x  3 gapi.ad_msg("Spawned zombie and created makeshift crowbar")                                                       x
x  4                                                                                                                   x
x                                                                                                                      x
mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj

```
