```text
lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk
^ : 'solvent trap' suppressor                                             #0: filter_suppressor                        x
x % 'special' brownie (fresh)                                                                                          x
x % 'special' chewy candy                         Origin: 'Bright Nights'                                              x
x ! (ethanol) filtered high quality crude oil     --                                                                   x
x ! (ethanol) filtered low quality crude oil      Material: Steel                                                      x
x ! (ethanol) high quality crude oil              Volume: 0.750 L  Weight: 0.88 kg                                     x
x ! (ethanol) low quality crude oil               Category: MODS                                                       x
x # .22 19-round tube speedloader                 --                                                                   x
x # .22 8-round speedloader                       This is an automotive filter crudely adapted to mate up with a       x
x = .22 CPHP                                      firearm's barrel, generating an illegal, unregistered suppressor.    x
x = .22 LR                                        Good thing there don't seem to be any ATF agents around to arrest    x
x = .22 LR CPHP, black powder                     you.  While close in design to a real suppressor, it was not designedx
x = .22 LR, black powder                          for high pressures involved and will eventually lose effectiveness.  x
x : .22 caliber conversion kit                    The installed filter is large and, when attached, will interfere withx
x = .22 casing                                    your ability to aim down the base sights of the gun.                 x
x = .22 rat-shot                                  --                                                                   x
x = .30-06 M14A1 tracer                           Melee damage: Bash: 3  To-hit bonus: +1                              x
x = .30-06 M2 AP                                  Moves per attack: 91                                                 x
x = .30-06 M2 AP, black powder                    Stamina Cost: 183                                                    x
x = .30-06 Springfield                            Typical damage per second:                                           x
x = .30-06 Springfield tracer, black powder       Best: 4.89  Vs. Agile: 2.46  Vs. Armored: 0.00                       x
x = .30-06 Springfield, black powder              --                                                                   x
x = .30-06 casing                                 Average melee damage:                                                x
x # .30-06 clip                                   Critical hit chance 8% - 27%                                         x
x = .300 AAC Blackout                             Bashing: 8  Critical bash: 12                                        x
x : .300 AAC Blackout AR-15 conversion kit        Moves per attack: 105                                                x
x = .300 AAC Blackout, black powder               --                                                                   x
x = .300 AAC Blackout, subsonic                   Dispersion modifier: +100                                            x
x = .300 Win Mag casing                           --                                                                   x
x = .300 Winchester Magnum                        Used on:                                                             x
x = .300 Winchester Magnum, black powder            Category: [Pistols], [Submachine Guns], [Rifles], [Machine Guns],  x
x = .300BLK casing                                or [Gatling Guns]                                                    x
x = .32 ACP                                       Location: muzzle                                                     x
x = .32 ACP casing                                --                                                                   x
x = .32 ACP, black powder                         Repair using advanced 3D printer, charcoal forge, Advanced Grid 3D   x
x = .357 Magnum FMJ, black powder                 Printer, grid forge, grid welder, electric forge, integrated toolset,x
v = .357 Magnum JHP, black powder                 [/] find, [f] container, [F] flag, [E] everything, [ESC] quit        x
mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq* This item can be reinforced.--* This item conducts electricity.* ThY

```
