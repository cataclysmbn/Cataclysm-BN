```text
 ......                                                          lq< Throwing telescoping umbrella >qqqqqqqqqqqqqqqqqqqk
   ......                                                        xRange: 2/36 Elevation: 0 Targets: 1                  x
     .....                                                       xNPC: 아비게일 홀                                     x
       .....                                                     xAware of your presence!                              x
         .....                                                   xWielding a pair of brass knuckles                    x
           .....                                                 x                                                     x
             ....                                                xSymbols: * = Great + = Normal | = Graze              x
              .....            ..                                x[f] Current Aim: Moves to fire: 89                   x
                .....         qq"q                               x[*****************++++++++++++++++++++++++++++++++++]x
                  .....        #...                              x                                                     x
                    ....       6...                              x                                                     x
                      ....    qq....                             x                                                     x
                        .... x#=.#..                             x                                                     x
                          ...x#..#..                             x                                                     x
                            ."#..#...                            x                                                     x
                             x#..#...                            x                                                     x
                             x...#...                            x                                                     x
..........                   x#..#...qqq      . x                x                                                     x
..............*..............x#..#..X##{{...#..#x................x                                                     x
.............................0...#....@.....#..#0................x                                                     x
.............................x...#...##.##.....#x................x                                                     x
..........                   mqq.............qq x                x                                                     x
                               {.............                    x                                                     x
                               {........6###                     xMove cursor with directional keys                    x
                               {......&lqqqq                     xMouse: LMB: Target, Wheel: Cycle, RMB: Fire          x
                               q0q+&q"qj                         x[TAB] Cycle targets; [f] to throw.                   x
                              ... .....                          x[0] target self; [*] toggle snap-to-target           x
                             ..: ...:.                           mqqqqqqqqqqqqqqqqqqqqqqqqqqqq< [?] show all controls >j
                            ...  .. :.                                       floor.
                           ...  ... :.                                       You hear thump! x 4
                          ...   .. .:.
                         ...   :.. .:.                                       NW:           North:        NE:
                        ...    ..  ...                                       West:                     East:
                       ...    ...  ..:                                       SW:           South:        SE:
                      ...     ..  ..::
                     ...     ...  .::.
                    ...      ...  ....
                   ...      ...   :..
                  ...      ....   ...

```
