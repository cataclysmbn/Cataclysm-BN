```text
.....                                                 .,,.,,,...f            Press } to open sidebar options
.......                                              ......,....             HEAD : █████   TORSO: █████   L ARM: █████
 ........                                           ..........            .. R ARM: █████   L LEG: █████   R LEG: █████
   ........                                        ,........            .... Sound: 6       Mood : :|      Focus: 96
     .......                                      ....,.,.            ...... Stam : ████▁   Speed: 100     Move : 0(W)
        ......            ..                     .......,           ........ Mana : 1006       Max Mana : 1100
          ......         qq"q                   .......           .......... Str  : 12      Dex  : 7       Power: 250kJ
            ......        #...  .qqqqqq        .......         ............. Int  : 9       Per  : 12      Safe : On
              .....       6...   .......      ......         ............... Place: evac shelter                   .....
                .....    qq....   ##.....  x .....         ................. X,Y,Z: -43, -61, 0                    .....
                  ..... x#..#..   .....#.. x....         ................... Sky  : Fair                           ..+..
                    ....x#..#..    #...#..#x...        ..................... Light: bright                         .┌┘..
.                     .."#..#... qqq...#..#".       ........................ Date : Spring, day 16                 ┌┘...
.......                 x#..#... >>....#...x      .......................... Time : 8:00:18 AM
.............           x...#...  >....#..#lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk Wield: fists
...................     x#..#...qqqq...#..#x Spawning…                     x Style: No style
.........*..............x#..#..@##{{...#..#tqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqu Wgt  : 4.6/61.0       Volume:0.85/17.50
........................0...#..........#..#x w Spawn an item               x Pain :                Thirst:Hydrated
........................x...#...##.##.....#x n Spawn NPC                   x Rest :                Hunger:Sated
.....                   mqq...........@.lqqx m Spawn monster               x Heat : Comfortable
                          {.............+  x v Spawn a vehicle             x Sound: 6
                          {........6####x  x a Spawn artifact              x light.
                          {......&lqqqqqj  x c Spawn clairvoyance artifact x There is nothing that can be closed
                          q0q+&q"qj        mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj nearby.
                         .........                                           You don't have any battery to reload your
                        ..:....:.                                            reading light!
                       ...:....:.                                            There is nothing to pick up nearby.
                      ....:....:.                                            Never mind.
                     .....:....:.                                            There is nothing to pick up nearby.
                    ......:....:.                                            Never mind.
                   ..............
                  ..............:                                            NW:           North:        NE:
                 ..............::                                            West:                     East:
                ..............::.                                            SW:           South:        SE:
               ..................
              ..............::..
             ..............::...
            ..............::....
           .....................

```
