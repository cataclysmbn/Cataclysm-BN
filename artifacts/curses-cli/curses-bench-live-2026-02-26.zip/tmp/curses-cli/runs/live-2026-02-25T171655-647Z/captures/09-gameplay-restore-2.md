```text
 ......                                                                      Press } to open sidebar options
   ......                                                                    HEAD : █████   TORSO: █████   L ARM: █████
     .....                                                                   R ARM: █████   L LEG: █████   R LEG: █████
       .....                                                                 Sound: 6       Mood : :|      Focus: 96
         .....                                                               Stam : ████▁   Speed: 100     Move : 0(W)
           .....                                                             Mana : 1006       Max Mana : 1100
             ....                                                            Str  : 12      Dex  : 7       Power: 250kJ
              .....            ..                                            Int  : 9       Per  : 12      Safe : On
                .....         qq"q                                           Place: evac shelter                   .....
                  .....        #...          lqqqqqqqqqqqqqqqqqqqqqqqqqqqqk  X,Y,Z: -43, -61, 0                    .....
                    ....       6...          x MAIN MENU                  x  Sky  : Fair                           ..+..
                      ....    qq....         tqqqqqqqqqqqqqqqqqqqqqqqqqqqqu  Light: bright                         .┌┘..
                        .... x#=.#..         x w Open Wiki                x  Date : Spring, day 16                 ┌┘...
                          ...x#..#..         x h Open Hitchhiker's Guide  x  Time : 8:00:08 AM
                            ."#..#...        x 0 View Help                x  Wield: fists
                             x#..#...        x 1 Display keybindings menu x  Style: No style
                             x...#...        x 2 Options                  x  Wgt  : 4.6/61.0       Volume:0.85/17.50
..........                   x#..#...qqq     x 3 Autopickup manager       x. Pain :                Thirst:Hydrated
..............*..............x#..#..@##{{...#x 4 Autonotes manager        x. Rest :                Hunger:Sated
.............................0...#....@.....#x 5 Safe Mode manager        x. Heat : Comfortable
.............................x...#...##.##...x 6 Distractions manager     x. Sound: 6
..........                   mqq.............x 7 Color manager            x. in one of the many government evac
                               {.............x 8 Active World Mods        x  shelters.
                               {........6### x 9 Action Menu              x  You hear thump! x 3
                               {......&lqqqq x a Quicksave                x  You don't seem to be damaging the wooden
                               q0q+&q"qj     x S Save and Quit            x  floor.
                              ... .....      x b Debug Menu               x  You hear thump! x 2
                             ..: ...:.       x ` Lua Console              x  You don't seem to be damaging the wooden
                            ...  .. :.       x c Reload Lua Code          x  floor.
                           ...  ... :.       mqqqqqqqqqqqqqqqqqqqqqqqqqqqqj  You hear thump! x 4
                          ...   .. .:.
                         ...   :.. .:.                                       NW:           North:        NE:
                        ...    ..  ...                                       West:                     East:
                       ...    ...  ..:                                       SW:           South:        SE:
                      ...     ..  ..::
                     ...     ...  .::.
                    ...      ...  ....
                   ...      ...   :..
                  ...      ....   ...

```
