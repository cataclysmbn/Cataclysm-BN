```text
lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk
x ; makeshift crowbar                                                   #3642: makeshift_crowbar                       x
x                                                                                                                      x
x                                                 Origin: 'Bright Nights'                                              x
x                                                 --                                                                   x
x                                                 Material: Steel                                                      x
x                                                 Volume: 0.500 L  Weight: 1.25 kg                                     x
x                                                 Category: ENTRY TOOLS                                                x
x                                                 Weapon Category: One-handed Hooking, Clubs                           x
x                                                 --                                                                   x
x                                                 This is a pipe whose ends have been bent and hammered flat to        x
x                                                 resemble a crowbar.  Use it to open locked crates without destroying x
x                                                 them, to lift manhole covers, or even open doors and windows.  You   x
x                                                 could also wield it to fight with, in a pinch.                       x
x                                                 --                                                                   x
x                                                 Melee damage: Bash: 12  Cut: 1  To-hit bonus: -1                     x
x                                                 Moves per attack: 93                                                 x
x                                                 Stamina Cost: 205                                                    x
x                                                 Typical damage per second:                                           x
x                                                 Best: 6.56  Vs. Agile: 2.69  Vs. Armored: 0.30                       x
x                                                 --                                                                   x
x                                                 Techniques when wielded: Block: Medium blocking ability              x
x                                                 --                                                                   x
x                                                 Average melee damage:                                                x
x                                                 Critical hit chance 5% - 20%                                         x
x                                                 Bashing: 13  Critical bash: 20                                       x
x                                                 Cutting: 1  Critical cut: 1                                          x
x                                                 Moves per attack: 107                                                x
x                                                 --                                                                   x
x                                                 Has level 1 hammering quality.                                       x
x                                                 Has level 1 prying quality.                                          x
x                                                 --                                                                   x
x                                                 Repair using advanced 3D printer, charcoal forge, Advanced Grid 3D   x
x                                                 Printer, grid forge, grid welder, electric forge, integrated toolset,x
x                                                 arc welder, or makeshift arc welder.                                 x
x                                                 * This item can be reinforced.                                       x
x                                                 --                                                                   x
x                                                 [/] find, [f] container, [F] flag, [E] everything, [ESC] quit sawing x
mq< makeshift crowbar >qqqqqqqqqqqqqqqqqqqqqqqqqqqof 1 or more and might yield: scrap metal (3) and chunk of steel (1).Y

```
